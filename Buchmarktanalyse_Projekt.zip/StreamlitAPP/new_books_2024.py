import pandas as pd

data = [
    [2024, "Here One Moment", "Liane Moriarty", "en", "Famous", 4.0, 226112, 65500000, "Crown", "Thriller", "9780593798607"],
    [2025, "The Last Anniversary", "Liane Moriarty", "en", "Famous", 3.8, 162406, 900000, "other", "Mystery", "9780062437105"],
    [2021, "Crossroads", "Jonathan Franzen", "en", "Famous", 4.1, 64000, 5400000, "Farrar", "Fiction", "9780374181178"],
    [2023, "Die Einladung", "Sebastian Fitzek", "de", "Famous", 4.0, 11000, 6000000, "Hardcover", "Triller", "9783426281581"],
    [2023, "Das Kalendermädchen", "Sebastian Fitzek", "de", "Famous", 4.0, 10000, 4000000, "Droemer", "Triller", "9783426281741"],
    [2025, "The Last Sunrise", "Anna Todd", "en", "Famous", 3.7, 300, 2000000, "Gallery Books", "Romance", "9781668079539"],
    [2023, "Someone Else's Shoes", "Jojo Moyes", "en", "Famous", 4.0, 234536, 3000000, "Penguin", "Romance", "9781984879297"],
    [2025, "We All Live Here", "Jojo Moyes", "de", "Famous", 4.0, 62000, 4000000, "Penguin", "Romance", "9781984879325"],
    [2023, "Inheritance", "Nora Roberts", "en", "Famous", 4.3, 61600, 3500000, "Macmillan", "Romance", "9781250289051"],
    [2025, "The Becoming", "Nora Roberts", "en", "Famous", 4.3, 47000, 4000000, "St. Martin’s Press", "Fantasy", "9781250272701"],
    [2023, "Die Farbe der Rache", "Cornelia Funke", "de", "Famous", 3.9, 4250, 3000000, "Dressler", "Fantasy", "9783789109703"],
    [2022, "Fairy Tale", "Stephen King", "en", "Famous", 4.1, 667700, 6000000000, "Scribner", "Fantasy", "9781668002179"],
    [2023, "Holly", "Stephen King", "en", "Famous", 4.1, 168800, 7000000000, "Scribner", "Horror", "9781668016138"],
    [2024, "You Like It Darker", "Stephen King", "en", "Famous", 4.2, 47000, 7000000000, "St. Martin’s Press", "Horror", "9781668037713"],
]

columns = [
    "Publishing_Year",
    "Book_Name",
    "Author",
    "Language_Code",
    "Author_Rating",
    "Average_Rating",
    "Rating_Count",
    "Gross_Sales_EUR",
    "Publisher",
    "Genre",
    "ISBN"
]

df = pd.DataFrame(data, columns=columns)
df.to_csv("new_books_2024.csv", index=False, encoding="utf-8")
print("✅ Datei 'new_books_2024.csv' wurde mit ISBNs gespeichert.")
